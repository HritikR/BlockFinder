chrome.extension.sendMessage({}, function (response) {
    console.log("BlockFinder Loaded");
    var readyStateCheckInterval = setInterval(function () {
        if (document.readyState === "complete") {
            var site = location.href;
            if (site.includes('kodular')) {
                var projectName = document.getElementsByClassName('project-name-textbox')[0];
                var url = 'https://cdn.jsdelivr.net/gh/HritikR/BlockFinder@latest/scripts/kodular.js';
            } else if (site.includes('appinventor')) {
                var projectName = document.getElementsByClassName('ya-ProjectName')[0];
                var url = 'https://cdn.jsdelivr.net/gh/HritikR/BlockFinder@latest/scripts/ai.js';
            }
            if (typeof (projectName) != 'undefined') {
                var checkValue = projectName.value != undefined ? projectName.value != '' ? true : false : false;
                if (checkValue || projectName.textContent != '') {
                    clearInterval(readyStateCheckInterval);
                    loadScript();
                }
            }

            function loadScript() {
                console.log('Loading JQuery')
                var script = document.createElement("SCRIPT");
                script.src = 'https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js';
                script.type = 'text/javascript';
                document.getElementsByTagName("head")[0].appendChild(script);
                if (site.includes("kodular")) {
                    document.getElementById('material-button-24').addEventListener('click', function(){
                        loadbfS();
                        this.removeEventListener('click', arguments.callee);
                    });
                } else if (site.includes("appinventor")) {
                    document.getElementsByClassName('ode-TextButton')[14].addEventListener('click', function(){
                        loadbfS();
                        this.removeEventListener('click', arguments.callee);
                    });
                }

            }
            function loadbfS() {
                console.log('Loading bfS')
                var script = document.createElement("SCRIPT");
                script.src = url;
                script.type = 'text/javascript';
                script.id = 'cobF-0';
                document.getElementsByTagName("head")[0].appendChild(script);
            }

        }
    }, 500);
});